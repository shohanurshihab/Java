package interfaces;

import java.lang.*;
import classes.*;
public interface IQuantity{
  public boolean addQuantity(int amount);
  public boolean sellQuantity(int amount);
}
